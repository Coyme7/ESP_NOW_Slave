#pragma once

// 从机串口日志配置。
//
// 日志只允许在启动路径和 Core 0 状态任务中输出，禁止进入控制热路径。

// 启动配置日志开关。
// 默认值：1，上电时打印模式、硬件开关、信道和关键控制分频。
// 用途：现场确认烧录对象、默认配置和无线信道是否正确。
// 风险：只在启动时输出；关闭后排查配置漂移会更困难。
// 依赖：不影响运行期状态任务。
#ifndef SLAVE_BOOT_LOG_ENABLED
#define SLAVE_BOOT_LOG_ENABLED 1
#endif

// 低频状态任务总开关。
// 默认值：1，创建 SlaveStatus 任务。
// 用途：周期打印摘要、XY 和 timing 状态。
// 风险：串口输出会占用 Core 0 时间；性能压测时可关闭。
// 依赖：关闭后下面的细分日志开关都不会输出。
#ifndef SLAVE_STATUS_LOG_ENABLED
#define SLAVE_STATUS_LOG_ENABLED 1
#endif

// 状态任务周期。
// 默认值：500ms，降低串口输出对无线和控制观测的反向干扰。
// 用途：控制运行期串口输出频率。
// 风险：值过小会增加 Core 0 压力，值过大不利于人工观察。
// 依赖：仅在 SLAVE_STATUS_LOG_ENABLED=1 时生效。
#ifndef SLAVE_STATUS_LOOP_PERIOD_MS
#define SLAVE_STATUS_LOOP_PERIOD_MS 500UL
#endif

// 从机摘要状态行开关。
// 默认值：1，输出模式、收包计数、fault、UV 和命令年龄。
// 用途：低成本观察链路和安全状态。
// 风险：摘要行仍有 Serial.printf 开销，只允许在状态任务中使用。
// 依赖：受 SLAVE_STATUS_LOG_ENABLED 总开关控制。
#ifndef SLAVE_STATUS_SUMMARY_LOG_ENABLED
#define SLAVE_STATUS_SUMMARY_LOG_ENABLED 1
#endif

// 从机 XY 状态行开关。
// 默认值：1，输出命令、目标、实际角、误差和限位。
// 用途：SingleX 同步验收和后续 Y 框架观察。
// 风险：包含浮点格式化，输出开销明显高于摘要行。
// 依赖：状态任务读取 SlaveMotionSnapshot，不直接读控制热路径或传感器。
#ifndef SLAVE_STATUS_XY_LOG_ENABLED
#define SLAVE_STATUS_XY_LOG_ENABLED 1
#endif

// 从机 timing 状态行开关。
// 默认值：1，配合 SLAVE_TIMING_DIAG_LEVEL 输出整步或分段耗时。
// 用途：对比 5kHz/2kHz 和定位 sensor/loopFOC/move 尖峰。
// 风险：状态行长，串口输出本身会增加 Core 0 负载。
// 依赖：SLAVE_TIMING_DIAG_LEVEL=0 时字段保持 0 或不输出分段含义。
#ifndef SLAVE_STATUS_TIMING_LOG_ENABLED
#define SLAVE_STATUS_TIMING_LOG_ENABLED 1
#endif

// YSensorOnly 状态任务读 Y 编码器开关。
// 默认值：1，但只有 SLAVE_Y_BRINGUP_MODE=SLAVE_Y_BRINGUP_SENSOR_ONLY 且 Y 传感器启用时才会真正读硬件。
// 用途：Y 传感器专用 bring-up 低频观测。
// 风险：如果 X/Y 共享 SPI，不能与 X 闭环同时使用；互斥由 build options 静态检查保护。
// 依赖：SLAVE_Y_SENSOR_HW_ENABLED=1 且 SLAVE_Y_BRINGUP_MODE=SLAVE_Y_BRINGUP_SENSOR_ONLY。
#ifndef SLAVE_STATUS_Y_SENSOR_BRINGUP_LOG_ENABLED
#define SLAVE_STATUS_Y_SENSOR_BRINGUP_LOG_ENABLED 1
#endif
